from django.shortcuts import render

# Create your views here.
def index(request):
	return render(request, 'app1/index1.html')

def catalogo(request):
	return render(request, 'app1/catalogo1.html')

def contacto(request):
	return render(request, 'app1/contacto1.html')

def plataforma(request):
	return render(request, 'app1/plataforma1.html')

def inventario(request):
	return render(request, 'app1/inventario1.html')

